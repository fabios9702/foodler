//
//  ImageView.swift
//  foodler
//
//  Created by Fabio Salvo on 23/03/18.


import UIKit
import AVKit
//initialization of objects
var tomatoImageView = UIImageView(image: UIImage(named: "tomato.png"))
var cheeseImageView = UIImageView(image: UIImage(named: "cheese.png"))
var potatoImageView = UIImageView(image: UIImage(named: "fried_potatoes.png"))
let backgroundImg = UIImageView(image: UIImage(named: "floor.png"))
let tableImg = UIImageView(image: UIImage(named: "table.png"))
let emptyOwenImage = UIImageView(image: UIImage(named: "empty_owen.png"))
let emptyOwenPieImage = UIImageView(image: UIImage(named: "empty_owen.png"))
var potImageView = UIImageView(image: UIImage(named: "pot.png"))
var potOnFlameImageView = UIImageView(image: UIImage(named: "pentola_su_fuoco.png"))
var spaghettiImageView = UIImageView(image: UIImage(named: "spaghetti.png"))
var tomatoForPastaImageView = UIImageView(image: UIImage(named: "tomato.png"))
var basilImageView = UIImageView(image: UIImage(named: "basil.png"))
var eggsImageView = UIImageView(image: UIImage(named: "eggs.png"))
var flourImageView = UIImageView(image: UIImage(named: "flour.png"))
var apricotImageView = UIImageView(image: UIImage(named: "apricot.png"))
var butterImageView = UIImageView(image: UIImage(named: "butter.png"))
var centeredImage = UIImageView(image: UIImage(named: "pizza_bianca.png"))
var squareTable = UIImageView(image: UIImage(named: "square_table.png"))
let player = try! AVAudioPlayer(contentsOf: Bundle.main.url(forResource: "KitchenTimerSound", withExtension: "mp3")!)
let levelLabel = UILabel()


extension ViewController{
    //setting the view
    func addViews() {
    squareTable.layer.zPosition = 1
    centeredImage.layer.zPosition = 2
    levelLabel.text = "Pizza"
    levelLabel.font = UIFont.boldSystemFont(ofSize: 50)
    tableImg.layer.zPosition = 1
    levelLabel.frame = CGRect(x: 0, y: 0, width: 200, height: 100)
    view.bringSubview(toFront: centeredImage)
    view.sendSubview(toBack: backgroundImg)
    self.view.addSubview(levelLabel)
    self.view.addSubview(squareTable)
    self.view.addSubview(centeredImage)
    self.view.addSubview(backgroundImg)
    self.view.addSubview(tableImg)
    setInitialConstraints()
    }
//    add the coffee objects to the view
    public func addPizzaViews(){
        centeredImage.image = UIImage(named: "pizza_bianca.png")
        centeredImage.isHidden = false
        centeredImage.layer.zPosition = 2
        squareTable.layer.zPosition = 1
        squareTable.isHidden = false
        cheeseImageView.layer.zPosition = 1
        tomatoImageView.layer.zPosition = 1
        potatoImageView.layer.zPosition = 1
        emptyOwenImage.isHidden = true
        tomatoImageView.isHidden = false
        cheeseImageView.isHidden = false
        potatoImageView.isHidden = false
        potImageView.isHidden = true
        spaghettiImageView.isHidden = true
        tomatoForPastaImageView.isHidden = true
        basilImageView.isHidden = true
        flourImageView.isHidden = true
        eggsImageView.isHidden = true
        butterImageView.isHidden = true
        apricotImageView.isHidden = true
        emptyOwenPieImage.isHidden = true
        view.bringSubview(toFront: centeredImage)
        self.view.backgroundColor = UIColor.white
        self.view.addSubview(centeredImage)
        self.view.addSubview(squareTable)
        self.view.addSubview(tomatoImageView)
        self.view.addSubview(cheeseImageView)
        self.view.addSubview(potatoImageView)
        self.view.addSubview(emptyOwenImage)
        setUpPizzaButton()
        setupPizzaGestures()
        setPizzaViewConstraint()
    }

}

