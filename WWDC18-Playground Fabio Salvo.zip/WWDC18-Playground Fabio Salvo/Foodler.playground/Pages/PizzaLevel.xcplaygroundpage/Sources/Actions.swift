//
//  Actions.swift
//  foodler
//
//  Created by Fabio Salvo on 23/03/18.


import UIKit

extension ViewController{
      //    Here there are the actions that the object do when are invocated with the geture recognizer. This functions are called in Gesture.swif file as #selector
         @objc public func potatoesDidDragged(){
            let newPoint = potatoesPanGesture.location(in: view)
            let newframe = CGRect(origin: CGPoint(x: newPoint.x, y: newPoint.y), size: CGSize (width: potatoImageView.frame.size.width, height: potatoImageView.frame.size.height))
            potatoImageView.frame = newframe
            if centeredImage.frame.contains(potatoImageView.frame){
                centeredImage.frame = CGRect(x: self.view.frame.width/2.36, y: self.view.frame.height/2, width: 600, height: 600)
                self.view.addSubview(centeredImage)
                centeredImage.image = UIImage(named: "pizza_patatine.png")
                emptyOwenImage.isHidden = false
                potatoImageView.isHidden = true
                
            }
        }
        
         @objc public func tomatoDidDragged(){
            let newPoint = tomatoPanGesture.location(in: view)
            let newframe = CGRect(origin: CGPoint(x: newPoint.x, y: newPoint.y), size: CGSize (width: tomatoImageView.frame.size.width, height: tomatoImageView.frame.size.height))
            tomatoImageView.frame = newframe
            if centeredImage.frame.contains(tomatoImageView.frame){
                centeredImage.frame = CGRect(x: self.view.frame.width/2.36, y: self.view.frame.height/2, width: 600, height: 600)
                self.view.addSubview(centeredImage)
                centeredImage.image = UIImage(named: "pizza_salsa.png")
                tomatoImageView.isHidden = true
                
            }
        }
        
        
        @objc public func cheeseDidDragged(){
            let newPoint = cheesePanGesture.location(in: view)
            let newframe = CGRect(origin: CGPoint(x: newPoint.x, y: newPoint.y), size: CGSize (width: cheeseImageView.frame.size.width, height: cheeseImageView.frame.size.height))
            cheeseImageView.frame = newframe
            if centeredImage.frame.contains(cheeseImageView.frame){
                centeredImage.frame = CGRect(x: self.view.frame.width/2.36, y: self.view.frame.height/2, width: 600, height: 600)
                self.view.addSubview(centeredImage)
                centeredImage.image = UIImage(named: "pizza_formaggio.png")
                cheeseImageView.isHidden = true
            }
        }
    
}
  

