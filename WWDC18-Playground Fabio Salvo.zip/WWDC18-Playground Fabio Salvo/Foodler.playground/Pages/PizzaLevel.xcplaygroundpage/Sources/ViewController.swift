//
//  ViewController.swift
//  foodler
//
//  Created by Fabio Salvo on 19/03/18.


import UIKit

public class ViewController: UIViewController {
    
    let frame = UIScreen.main.bounds
    var pizzaTimer = 30

    override public func viewDidLoad() {
        
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
//       adding all prevoius setting to the ViewController in order to start the live view
        addViews()
        addPizzaViews()
        setUpPizzaButton()
        setupPizzaGestures()
    }
   
}


