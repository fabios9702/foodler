//
//  Gestures.swift
//  foodler
//
//  Created by Fabio Salvo on 23/03/18.

import UIKit
// initialization of Gesture Recognizer
var tomatoPanGesture = UIPanGestureRecognizer()
var cheesePanGesture = UIPanGestureRecognizer()
var potatoesPanGesture = UIPanGestureRecognizer()
var flourPanGesture = UIPanGestureRecognizer()
var eggsPangesture = UIPanGestureRecognizer()
var apricotPanGesture = UIPanGestureRecognizer()
var butterPanGesture = UIPanGestureRecognizer()
var PizzaOwenTap = UITapGestureRecognizer()
var PieOwenTap = UITapGestureRecognizer()
var tomatoForPastaPanGesture = UIPanGestureRecognizer()
var potPanGesture = UIPanGestureRecognizer()
var spaghettiPanGesture = UIPanGestureRecognizer()
var basilPanGesture = UIPanGestureRecognizer()

extension ViewController{
    //    function to set up the drag & drop of the ingredients in the dish
    
    public func setupPizzaGestures(){
        //        Add the Tap Gesture to the Pizza owen
        emptyOwenImage.isUserInteractionEnabled = true
        PizzaOwenTap = UITapGestureRecognizer(target: self, action: #selector(openPizzaOwen))
        emptyOwenImage.addGestureRecognizer(PizzaOwenTap)
        
        //        Add the Pan Gesture to tomato
        tomatoImageView.isUserInteractionEnabled = true
        tomatoPanGesture = UIPanGestureRecognizer(target: self, action: #selector(tomatoDidDragged))
        tomatoPanGesture.minimumNumberOfTouches = 1
        tomatoPanGesture.maximumNumberOfTouches = 1
        tomatoImageView.addGestureRecognizer(tomatoPanGesture)
        
        //        Add the Pan Gesture to cheese
        cheeseImageView.isUserInteractionEnabled = true
        cheesePanGesture = UIPanGestureRecognizer(target: self, action: #selector(cheeseDidDragged))
        cheesePanGesture.minimumNumberOfTouches = 1
        cheesePanGesture.maximumNumberOfTouches = 1
        cheeseImageView.addGestureRecognizer(cheesePanGesture)
        
        //        Add the Pan Gesture to potatoes
        potatoImageView.isUserInteractionEnabled = true
        potatoesPanGesture = UIPanGestureRecognizer(target: self, action: #selector(potatoesDidDragged))
        potatoesPanGesture.minimumNumberOfTouches = 1
        potatoesPanGesture.maximumNumberOfTouches = 1
        potatoImageView.addGestureRecognizer(potatoesPanGesture)
    }
 
}
