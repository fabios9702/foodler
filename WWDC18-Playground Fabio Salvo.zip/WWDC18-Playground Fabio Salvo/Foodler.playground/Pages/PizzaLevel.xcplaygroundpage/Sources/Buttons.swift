//
//  Buttons.swift
//  foodler
//
//  Created by Fabio Salvo on 23/03/18.


import Foundation
import UIKit
import AVKit

let cookPastaButton = UIButton()
let cookPieButton = UIButton()
let cookPizzaButton = UIButton()

extension ViewController {
//    Setting the setUpPizzaButton action and layout
    public func setUpPizzaButton(){
        cookPizzaButton.setTitle("Cook", for: .normal)
        cookPizzaButton.backgroundColor = #colorLiteral(red: 1, green: 0.7999603152, blue: 0, alpha: 1)
        cookPizzaButton.layer.cornerRadius = 20
        cookPizzaButton.titleLabel?.font =  UIFont(name: "Helvetica", size: 50)
        cookPizzaButton.addTarget(self, action: #selector(cookPizza), for: .allEvents)
        cookPizzaButton.pulsate()
        cookPizzaButton.translatesAutoresizingMaskIntoConstraints = false
        cookPizzaButton.layer.zPosition = 1
        cookPizzaButton.isHidden = true
        self.view.addSubview(cookPizzaButton)
        setUpPizzaButtonConstrains()
        
    }
//    this is the function added to the setUpPizzaButton
    @objc public func cookPizza(){
            cookPizzaButton.isHidden = true
            let timer = Timer.scheduledTimer(timeInterval: 1.5, target: self, selector: #selector(pizza), userInfo: nil, repeats: false)
             player.play()
        
    }
    
    @objc func pizza() {
        centeredImage.isHidden = false
        centeredImage.image = UIImage(named: "pizza_cotta.png")
        emptyOwenImage.image = UIImage(named: "empty_owen.png")
    }
    
    @objc public func openPizzaOwen(){
        emptyOwenImage.image = UIImage(named: "full_owen.png")
        centeredImage.isHidden = true
        cookPizzaButton.isHidden = false
        
    }


}

//extension with function that allows to the button to pulsate
extension UIButton{
    func pulsate() {
        let pulse = CASpringAnimation(keyPath: "transform.scale")
        pulse.duration =  3
        pulse.fromValue = 0.90
        pulse.toValue = 1.0
        pulse.autoreverses = true
        pulse.repeatCount = .infinity
        pulse.initialVelocity = 0.5
        pulse.damping = 1.0
        layer.add(pulse, forKey: "pulse")
    }
}
