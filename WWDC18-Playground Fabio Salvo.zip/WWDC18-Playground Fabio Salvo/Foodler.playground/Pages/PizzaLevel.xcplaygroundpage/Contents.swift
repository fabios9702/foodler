//: [Previous Level](@previous)

//: ### -🍕 Pizza Level
/*:
 Pizza is one the most famous italian dish in the world. Pizza's origins are from Naples, here there are some organizations that aims to promote and protect... the true Neapolitan pizza. Pizza is sold fresh or frozen, either whole or in portions. The traditional pizza is "Margherita" but here we try to make a different version with potatoes.
 **hints:** start with the first one.
 When you finish click on Next Level.
 */
import PlaygroundSupport
import UIKit

let viewC = ViewController()
// Setting the dimension of the frame
viewC.preferredContentSize = CGSize(width: 600, height: 800)
// Starting the live view
PlaygroundPage.current.liveView = viewC
//: [Next Level](@next)
