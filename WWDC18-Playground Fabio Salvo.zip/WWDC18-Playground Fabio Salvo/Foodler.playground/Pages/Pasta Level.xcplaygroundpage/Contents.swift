//: [Previous Level](@previous)
//: ### -🍝 Pasta Level
/*:
 Also pasta is one of the most famous italian dishes in the world. "Pasta al pomodoro" is the model of the pasta in our coutry: It's a simple but tricky dish because if you don't use the right ingredients your pasta won't be as delicious as the orignal. Let's try, for the last time, to cook together pasta al pomodoro.
 **hints:** start with the first one.
 */
import PlaygroundSupport
import UIKit

let viewC = ViewController()
// Setting the dimension of the frame
viewC.preferredContentSize = CGSize(width: 600, height: 800)
// Starting the live view
PlaygroundPage.current.liveView = viewC


