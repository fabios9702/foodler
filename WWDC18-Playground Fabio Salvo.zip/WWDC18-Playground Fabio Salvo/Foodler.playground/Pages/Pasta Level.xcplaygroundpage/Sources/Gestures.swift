//
//  Gestures.swift
//  foodler
//
//  Created by Fabio Salvo on 23/03/18.


import UIKit
// initialization of Gesture Recognizer
var tomatoPanGesture = UIPanGestureRecognizer()
var cheesePanGesture = UIPanGestureRecognizer()
var potatoesPanGesture = UIPanGestureRecognizer()
var flourPanGesture = UIPanGestureRecognizer()
var eggsPangesture = UIPanGestureRecognizer()
var apricotPanGesture = UIPanGestureRecognizer()
var butterPanGesture = UIPanGestureRecognizer()
var PizzaOwenTap = UITapGestureRecognizer()
var PieOwenTap = UITapGestureRecognizer()
var tomatoForPastaPanGesture = UIPanGestureRecognizer()
var potPanGesture = UIPanGestureRecognizer()
var spaghettiPanGesture = UIPanGestureRecognizer()
var basilPanGesture = UIPanGestureRecognizer()

extension ViewController{
  //    function to set up the drag and drop of the ingredients in the dish

    
    public func setupPastaGestures(){
        //        Add the Pan Gesture to Pot
        potImageView.isUserInteractionEnabled = true
        potPanGesture = UIPanGestureRecognizer(target: self, action: #selector(potDidDragged))
        potPanGesture.minimumNumberOfTouches = 1
        potPanGesture.maximumNumberOfTouches = 1
        potImageView.addGestureRecognizer(potPanGesture)
        
        //        Add the Pan Gesture to Spaghetti
        spaghettiImageView.isUserInteractionEnabled = true
        spaghettiPanGesture = UIPanGestureRecognizer(target: self, action: #selector(spaghettiDidDragged))
        spaghettiPanGesture.minimumNumberOfTouches = 1
        spaghettiPanGesture.maximumNumberOfTouches = 1
        spaghettiImageView.addGestureRecognizer(spaghettiPanGesture)
        
        //        Add the Pan Gesture to Tomato for Spaghetti
        tomatoForPastaImageView.isUserInteractionEnabled = true
        tomatoForPastaPanGesture = UIPanGestureRecognizer(target: self, action: #selector(tomatoSpaghettiDidDragged))
        tomatoForPastaPanGesture.minimumNumberOfTouches = 1
        tomatoForPastaPanGesture.maximumNumberOfTouches = 1
        tomatoForPastaImageView.addGestureRecognizer(tomatoForPastaPanGesture)
        
        //        Add the Pan Gesture to basil
        basilImageView.isUserInteractionEnabled = true
        basilPanGesture = UIPanGestureRecognizer(target: self, action: #selector(basilDidDragged))
        basilPanGesture.minimumNumberOfTouches = 1
        basilPanGesture.maximumNumberOfTouches = 1
        basilImageView.addGestureRecognizer(basilPanGesture)
    }

    
}

