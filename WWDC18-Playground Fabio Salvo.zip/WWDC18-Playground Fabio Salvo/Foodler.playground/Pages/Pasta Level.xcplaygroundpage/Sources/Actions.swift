//
//  Actions.swift
//  foodler
//
//  Created by Fabio Salvo on 23/03/18.


import UIKit

extension ViewController{
//    Here there are the actions that the object do when are invocated with the geture recognizer. This functions are called in Gesture.swif file as #selector
    @objc public func basilDidDragged(){
        let newPoint = basilPanGesture.location(in: view)
        let newframe = CGRect(origin: CGPoint(x: newPoint.x, y: newPoint.y), size: CGSize (width: basilImageView.frame.size.width, height: basilImageView.frame.size.height))
        basilImageView.frame = newframe
        if centeredImage.frame.contains(basilImageView.frame){
            centeredImage.frame = CGRect(x: self.view.frame.width/2.36, y: self.view.frame.height/2, width: 600, height: 600)
            self.view.addSubview(centeredImage)
            centeredImage.image = UIImage(named: "spaghetti_done.png")
            basilImageView.isHidden = true
            basilImageView.isHidden = true
            let timer2 = Timer.scheduledTimer(timeInterval: 0.8, target: self, selector: #selector(done), userInfo: nil, repeats: false)
        }
    }
    
    @objc public func tomatoSpaghettiDidDragged(){
        let newPoint = tomatoForPastaPanGesture.location(in: view)
        let newframe = CGRect(origin: CGPoint(x: newPoint.x, y: newPoint.y), size: CGSize (width: tomatoForPastaImageView.frame.size.width, height: tomatoForPastaImageView.frame.size.height))
        tomatoForPastaImageView.frame = newframe
        if centeredImage.frame.contains(tomatoForPastaImageView.frame){
            centeredImage.frame = CGRect(x: self.view.frame.width/2.36, y: self.view.frame.height/2, width: 600, height: 600)
            self.view.addSubview(centeredImage)
            centeredImage.image = UIImage(named: "spaghetti_sauce.png")
            tomatoForPastaImageView.isHidden = true
            tomatoForPastaImageView.isHidden = true
            
        }
    }
    
    @objc public func spaghettiDidDragged(){
        let newPoint = spaghettiPanGesture.location(in: view)
        let newframe = CGRect(origin: CGPoint(x: newPoint.x, y: newPoint.y), size: CGSize (width: spaghettiImageView.frame.size.width, height: spaghettiImageView.frame.size.height))
        spaghettiImageView.frame = newframe
        if centeredImage.frame.contains(spaghettiImageView.frame){
            centeredImage.frame = CGRect(x: self.view.frame.width/2.36, y: self.view.frame.height/2, width: 600, height: 600)
            self.view.addSubview(centeredImage)
            cookPastaButton.isHidden = false
            spaghettiImageView.isHidden = true
        }
    }
    
    @objc public func potDidDragged(){
        let newPoint = potPanGesture.location(in: view)
        let newframe = CGRect(origin: CGPoint(x: newPoint.x, y: newPoint.y), size: CGSize (width: potImageView.frame.size.width, height: potImageView.frame.size.height))
        potImageView.frame = newframe
        if centeredImage.frame.contains(potImageView.frame){
            centeredImage.frame = CGRect(x: self.view.frame.width/2.36, y: self.view.frame.height/2, width: 600, height: 600)
            self.view.addSubview(centeredImage)
            centeredImage.image = UIImage(named: "pentola_su_fornello.png")
            potImageView.isHidden = true
        }
    }

}


