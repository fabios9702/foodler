//
//  ImageView.swift
//  foodler
//
//  Created by Fabio Salvo on 23/03/18.


import UIKit
import AVKit
//initialization of objects
var tomatoImageView = UIImageView(image: UIImage(named: "tomato.png"))
var cheeseImageView = UIImageView(image: UIImage(named: "cheese.png"))
var potatoImageView = UIImageView(image: UIImage(named: "fried_potatoes.png"))
let backgroundImg = UIImageView(image: UIImage(named: "floor.png"))
let tableImg = UIImageView(image: UIImage(named: "table.png"))
let emptyOwenImage = UIImageView(image: UIImage(named: "empty_owen.png"))
let emptyOwenPieImage = UIImageView(image: UIImage(named: "empty_owen.png"))
var potImageView = UIImageView(image: UIImage(named: "pot.png"))
var potOnFlameImageView = UIImageView(image: UIImage(named: "pentola_su_fuoco.png"))
var spaghettiImageView = UIImageView(image: UIImage(named: "spaghetti.png"))
var tomatoForPastaImageView = UIImageView(image: UIImage(named: "tomato.png"))
var basilImageView = UIImageView(image: UIImage(named: "basil.png"))
var eggsImageView = UIImageView(image: UIImage(named: "eggs.png"))
var flourImageView = UIImageView(image: UIImage(named: "flour.png"))
var apricotImageView = UIImageView(image: UIImage(named: "apricot.png"))
var butterImageView = UIImageView(image: UIImage(named: "butter.png"))
var centeredImage = UIImageView(image: UIImage(named: "pizza_bianca.png"))
var squareTable = UIImageView(image: UIImage(named: "square_table.png"))
let player = try! AVAudioPlayer(contentsOf: Bundle.main.url(forResource: "KitchenTimerSound", withExtension: "mp3")!)
let levelLabel = UILabel()
let doneImage = UIImageView(image: UIImage(named: "done.png"))


extension ViewController{
     //setting the view
    func addViews() {
        squareTable.layer.zPosition = 1
        centeredImage.layer.zPosition = 2
        levelLabel.text = "Pasta"
        levelLabel.font = UIFont.boldSystemFont(ofSize: 50)
        tableImg.layer.zPosition = 1
        levelLabel.frame = CGRect(x: 0, y: 0, width: 200, height: 100)
        view.bringSubview(toFront: centeredImage)
        view.sendSubview(toBack: backgroundImg)
        doneImage.isHidden = true
        doneImage.layer.zPosition = 3
        self.view.addSubview(doneImage)
        self.view.addSubview(levelLabel)
        self.view.addSubview(squareTable)
        self.view.addSubview(centeredImage)
        self.view.addSubview(backgroundImg)
        self.view.addSubview(tableImg)
        setInitialConstraints()
    }
    
 //    add the pasta objects to the view
    public func addPastaViews(){
        centeredImage.image = UIImage(named: "empty_owen.png")
        centeredImage.isHidden = false
        centeredImage.layer.zPosition = 2
        squareTable.layer.zPosition = 1
        squareTable.isHidden = true
        basilImageView.layer.zPosition = 1
        tomatoForPastaImageView.layer.zPosition = 1
        spaghettiImageView.layer.zPosition = 1
        potImageView.layer.zPosition = 1
        cookPizzaButton.isHidden = true
        emptyOwenImage.isHidden = true
        tomatoImageView.isHidden = true
        cheeseImageView.isHidden = true
        potatoImageView.isHidden = true
        potImageView.isHidden = false
        spaghettiImageView.isHidden = false
        tomatoForPastaImageView.isHidden = false
        basilImageView.isHidden = false
        flourImageView.isHidden = true
        eggsImageView.isHidden = true
        butterImageView.isHidden = true
        apricotImageView.isHidden = true
        emptyOwenPieImage.isHidden = true
        self.view.backgroundColor = UIColor.white
        self.view.addSubview(squareTable)
        self.view.addSubview(tomatoForPastaImageView)
        self.view.addSubview(basilImageView)
        self.view.addSubview(potImageView)
        self.view.addSubview(potOnFlameImageView)
        self.view.addSubview(spaghettiImageView)
        setPastaButton()
        setupPastaGestures()
        setPastaViewConstraints()
    }
}

