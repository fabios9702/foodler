//
//  Buttons.swift
//  foodler
//
//  Created by Fabio Salvo on 23/03/18.


import Foundation
import UIKit
import AVKit

let cookPastaButton = UIButton()
let cookPieButton = UIButton()
let cookPizzaButton = UIButton()

extension ViewController {
//    Setting the setPastaButton action and layout
    
    
    public func setPastaButton(){
        cookPastaButton.setTitle("Cook", for: .normal)
        cookPastaButton.backgroundColor = #colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1)
        cookPastaButton.layer.cornerRadius = 20
        cookPastaButton.titleLabel?.font =  UIFont(name: "Helvetica", size: 50)
        cookPastaButton.addTarget(self, action: #selector(cookPasta), for: .allEvents)
        cookPastaButton.pulsate()
        cookPastaButton.isHidden = true
        cookPastaButton.layer.zPosition = 1
        self.view.addSubview(cookPastaButton)
        setUpPastaButtonConstrains()
    }

//    this is the function added to the setUpPizzaButton
    @objc public func cookPasta(){
        cookPastaButton.isHidden = true
        let timer = Timer.scheduledTimer(timeInterval: 1.5, target: self, selector: #selector(pasta), userInfo: nil, repeats: false)
        player.play()
    }

    @objc public func pasta() {
        centeredImage.image = UIImage(named: "spaghetti_plate.png")
        squareTable.isHidden = false
    }
    
    @objc func done() {
        doneImage.isHidden = false
    }
}


extension UIButton{
    func pulsate() {
        let pulse = CASpringAnimation(keyPath: "transform.scale")
        pulse.duration =  3
        pulse.fromValue = 0.90
        pulse.toValue = 1.0
        pulse.autoreverses = true
        pulse.repeatCount = .infinity
        pulse.initialVelocity = 0.5
        pulse.damping = 1.0
        layer.add(pulse, forKey: "pulse")
    }
}

