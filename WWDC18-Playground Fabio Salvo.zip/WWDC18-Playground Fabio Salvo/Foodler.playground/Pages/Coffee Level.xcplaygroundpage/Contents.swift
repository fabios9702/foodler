//: [Info](@previous)
//: ### -☕️Coffee Level
/*:
 **BUONGIORNO!**
 In Italy we use to start the day with a coffee. But coffee for italian people is more than a short drink, we drink coffee when we meet friends, we drink coffee when we are in working break and when we finish eating. As you have understood in italy we drink a lot of coffee everyday; but, what make our coffee special?
     The way we make it! So, let's try togheter to make a good coffee. All you have to do is drag and drop the objects to the center.
 **hints:** start with the first one.
 When you finish click on Next Level.
 */

import PlaygroundSupport
import UIKit

let viewC = ViewController()
// Setting the dimension of the frame
viewC.preferredContentSize = CGSize(width: 600, height: 800)
// Starting the live view
PlaygroundPage.current.liveView = viewC

//: [Next Level](@next)
