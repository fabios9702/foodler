//
//  Gestures.swift
//  foodler
//
//  Created by Fabio Salvo on 23/03/18.

import UIKit
// initialization of Gesture Recognizer
var tomatoPanGesture = UIPanGestureRecognizer()
var cheesePanGesture = UIPanGestureRecognizer()
var potatoesPanGesture = UIPanGestureRecognizer()
var flourPanGesture = UIPanGestureRecognizer()
var eggsPangesture = UIPanGestureRecognizer()
var coffeePanGesture = UIPanGestureRecognizer()
var coffeeMachinePanGesture = UIPanGestureRecognizer()
var PizzaOwenTap = UITapGestureRecognizer()
var PieOwenTap = UITapGestureRecognizer()
var tomatoForPastaPanGesture = UIPanGestureRecognizer()
var potPanGesture = UIPanGestureRecognizer()
var spaghettiPanGesture = UIPanGestureRecognizer()
var basilPanGesture = UIPanGestureRecognizer()

extension ViewController{
    //    function to set up the drag & drop of the ingredients in the dish

    public func setupCoffeeGestures(){
        
        //        Add the Pan Gesture to coffee Machine
        coffeeMachineImageView.isUserInteractionEnabled = true
        coffeeMachinePanGesture = UIPanGestureRecognizer(target: self, action: #selector(coffeeMachineDidDragged))
        coffeeMachinePanGesture.minimumNumberOfTouches = 1
        coffeeMachinePanGesture.maximumNumberOfTouches = 1
        coffeeMachineImageView.addGestureRecognizer(coffeeMachinePanGesture)
        
        //        Add the Pan Gesture to coffee
        coffeeImageView.isUserInteractionEnabled = true
        coffeePanGesture = UIPanGestureRecognizer(target: self, action: #selector(coffeeDidDragged))
        coffeePanGesture.minimumNumberOfTouches = 1
        coffeePanGesture.maximumNumberOfTouches = 1
        coffeeImageView.addGestureRecognizer(coffeePanGesture)
        
    }
    
}

