//
//  Constraints.swift
//  foodler
//
//  Created by Fabio Salvo on 23/03/18.


import UIKit
//Creation of all constraints of the view
extension ViewController{

    public func setUpCoffeeButtonConstraints(){
        //        Constraints for CookCoffeeButton
        cookCoffeeButton.translatesAutoresizingMaskIntoConstraints = false
        let cookPieButtonWidthConstraint = cookCoffeeButton.widthAnchor.constraint(equalToConstant: 200)
        let cookPieButtonHeightConstraint = cookCoffeeButton.heightAnchor.constraint(equalToConstant: 100)
        let cookPieButtonXConstraint = cookCoffeeButton.centerXAnchor.constraint(equalTo: self.view.centerXAnchor)
        let cookPieButtonYConstraint = cookCoffeeButton.centerYAnchor.constraint(equalTo: self.view.centerYAnchor, constant: -200)
        NSLayoutConstraint.activate([cookPieButtonXConstraint, cookPieButtonYConstraint, cookPieButtonWidthConstraint, cookPieButtonHeightConstraint])
        
    }
 
    public func setInitialConstraints(){
        
        //        Constraints for CenterImage
        centeredImage.translatesAutoresizingMaskIntoConstraints = false
        let widthImageConstraint = centeredImage.widthAnchor.constraint(equalToConstant: 200)
        let heightImageConstraint = centeredImage.heightAnchor.constraint(equalToConstant: 200)
        let centerImageXConstraint = centeredImage.centerXAnchor.constraint(equalTo: self.view.centerXAnchor)
        let centerImageYConstraint = centeredImage.centerYAnchor.constraint(equalTo: self.view.centerYAnchor)
        NSLayoutConstraint.activate([widthImageConstraint, heightImageConstraint, centerImageXConstraint, centerImageYConstraint])
        
        //        Constraints for background
        backgroundImg.translatesAutoresizingMaskIntoConstraints = false
        let leadingBackgorundConstraint = backgroundImg.leadingAnchor.constraint(equalTo: self.view.leadingAnchor)
        let trailingBackgorundConstraint = backgroundImg.trailingAnchor.constraint(equalTo: self.view.trailingAnchor)
        let topBackgroundConstraint = backgroundImg.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 80)
        let bottomBackgroundConstraint = backgroundImg.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        NSLayoutConstraint.activate([leadingBackgorundConstraint, trailingBackgorundConstraint, topBackgroundConstraint, bottomBackgroundConstraint])
        
        //        Constraints for table
        tableImg.translatesAutoresizingMaskIntoConstraints = false
        let tableLeftConstraint = tableImg.leftAnchor.constraint(equalTo: self.view.leftAnchor, constant: 20)
        let tableRightConstraint = tableImg.rightAnchor.constraint(equalTo: self.view.rightAnchor, constant: -20)
        let tableHeightConstraint = tableImg.heightAnchor.constraint(equalToConstant: 86)
        let tableCenterXConstraint = tableImg.centerXAnchor.constraint(equalTo: self.view.centerXAnchor)
        let tableCenterYConstraint = tableImg.centerYAnchor.constraint(equalTo: self.view.centerYAnchor, constant: 200
        )
        NSLayoutConstraint.activate([tableLeftConstraint, tableRightConstraint, tableHeightConstraint, tableCenterXConstraint, tableCenterYConstraint])
        
        //        Constraints for squareTable
        squareTable.translatesAutoresizingMaskIntoConstraints = false
        let squareTableWidthConstraint = squareTable.widthAnchor.constraint(equalToConstant: 250)
        let squareTableHeightConstraint = squareTable.heightAnchor.constraint(equalToConstant: 250)
        let squareTableXPosition = squareTable.centerXAnchor.constraint(equalTo: self.view.centerXAnchor)
        let squareTableYPosition = squareTable.centerYAnchor.constraint(equalTo: self.view.centerYAnchor)
        NSLayoutConstraint.activate([squareTableWidthConstraint, squareTableHeightConstraint, squareTableXPosition, squareTableYPosition])
    }
    
    
    public func setCoffeeViewConstraints(){
        
        //        Constraints for coffee machine
        coffeeMachineImageView.translatesAutoresizingMaskIntoConstraints = false
        let butterWidthConstraint = coffeeMachineImageView.widthAnchor.constraint(equalToConstant: 70)
        let butterHeightConstraint = coffeeMachineImageView.heightAnchor.constraint(equalToConstant: 70)
        let butterXPosition = coffeeMachineImageView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor, constant: -50)
        let butterYPosition = coffeeMachineImageView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor, constant: 200)
        NSLayoutConstraint.activate([butterWidthConstraint, butterHeightConstraint, butterXPosition, butterYPosition])
        
        //        Constraint for coffee
        coffeeImageView.translatesAutoresizingMaskIntoConstraints = false
        let apricotWidthConstraint = coffeeImageView.widthAnchor.constraint(equalToConstant: 70)
        let apricotHeightConstraint = coffeeImageView.heightAnchor.constraint(equalToConstant: 70)
        let apricotXPosition = coffeeImageView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor, constant: 50)
        let apricotYPosition = coffeeImageView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor, constant: 200)
        NSLayoutConstraint.activate([apricotWidthConstraint, apricotHeightConstraint, apricotXPosition, apricotYPosition])
        

}
}
