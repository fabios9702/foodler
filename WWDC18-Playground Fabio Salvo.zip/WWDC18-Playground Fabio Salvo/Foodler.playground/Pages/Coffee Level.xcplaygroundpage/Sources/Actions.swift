//
//  Actions.swift
//  foodler
//
//  Created by Fabio Salvo on 23/03/18.

import UIKit

extension ViewController{
    //    Here there are the actions that the object do when are invocated with the geture recognizer. This functions are called in Gesture.swif file as #selector
    @objc public func coffeeDidDragged(){
        let newPoint = coffeePanGesture.location(in: view)
        let newframe = CGRect(origin: CGPoint(x: newPoint.x, y: newPoint.y), size: CGSize (width: coffeeImageView.frame.size.width, height: coffeeImageView.frame.size.height))
        coffeeImageView.frame = newframe
        if centeredImage.frame.contains(coffeeImageView.frame){
            centeredImage.frame = CGRect(x: self.view.frame.width/2.36, y: self.view.frame.height/2, width: 600, height: 600)
            self.view.addSubview(centeredImage)
            cookCoffeeButton.isHidden = false
            coffeeImageView.isHidden = true
        }
    }
    
    @objc public func coffeeMachineDidDragged(){
        let newPoint = coffeeMachinePanGesture.location(in: view)
        let newframe = CGRect(origin: CGPoint(x: newPoint.x, y: newPoint.y), size: CGSize (width: coffeeMachineImageView.frame.size.width, height: coffeeMachineImageView.frame.size.height))
        coffeeMachineImageView.frame = newframe
        if centeredImage.frame.contains(coffeeMachineImageView.frame){
            centeredImage.frame = CGRect(x: self.view.frame.width/2.36, y: self.view.frame.height/2, width: 600, height: 600)
            self.view.addSubview(centeredImage)
            centeredImage.image = UIImage(named: "caffettiera.png")
            coffeeMachineImageView.isHidden = true
        }
    }

}


