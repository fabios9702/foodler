//
//  ImageView.swift
//  foodler
//
//  Created by Fabio Salvo on 23/03/18.


import UIKit
import AVKit
//initialization of objects
let backgroundImg = UIImageView(image: UIImage(named: "floor.png"))
let tableImg = UIImageView(image: UIImage(named: "table.png"))
var coffeeImageView = UIImageView(image: UIImage(named: "caffè.png"))
var coffeeMachineImageView = UIImageView(image: UIImage(named: "caffettiera.png"))
var centeredImage = UIImageView(image: UIImage(named: "square_table.png"))
var squareTable = UIImageView(image: UIImage(named: "square_table.png"))
let player = try! AVAudioPlayer(contentsOf: Bundle.main.url(forResource: "coffeeMoka", withExtension: "mp3")!)
let levelLabel = UILabel()


extension ViewController{
//setting the view
    func addViews() {
        squareTable.layer.zPosition = 1
        centeredImage.layer.zPosition = 2
        levelLabel.text = "Coffee"
        levelLabel.frame = CGRect(x: 0, y: 0, width: 200, height: 100)
        levelLabel.font = UIFont.boldSystemFont(ofSize: 50)
        tableImg.layer.zPosition = 1
        view.bringSubview(toFront: centeredImage)
        view.sendSubview(toBack: backgroundImg)
        self.view.addSubview(squareTable)
        self.view.addSubview(levelLabel)
        self.view.addSubview(centeredImage)
        self.view.addSubview(backgroundImg)
        self.view.addSubview(tableImg)
        setInitialConstraints()
    }
//    add the coffee objects to the view
    public func addCoffeeViews() {
        centeredImage.image = UIImage(named: "")
        centeredImage.isHidden = false
        centeredImage.layer.zPosition = 2
        squareTable.layer.zPosition = 1
        self.view.backgroundColor = UIColor.white
        coffeeImageView.layer.zPosition = 1
        coffeeMachineImageView.layer.zPosition = 1
        coffeeMachineImageView.isHidden = false
        coffeeImageView.isHidden = false
        self.view.addSubview(squareTable)
        self.view.addSubview(coffeeImageView)
        self.view.addSubview(coffeeMachineImageView)
        self.view.addSubview(centeredImage)
        self.view.addSubview(backgroundImg)
        setCoffeeButton()
        setupCoffeeGestures()
        setCoffeeViewConstraints()
    }
    
}

