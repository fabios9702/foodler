//
//  Buttons.swift
//  foodler
//
//  Created by Fabio Salvo on 23/03/18.


import Foundation
import UIKit
import AVKit

let cookCoffeeButton = UIButton()

extension ViewController {
//    Setting the coffeeButton action and layout
    public func setCoffeeButton(){
        cookCoffeeButton.setTitle("Cook", for: .normal)
        cookCoffeeButton.backgroundColor = #colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1)
        cookCoffeeButton.layer.cornerRadius = 20
        cookCoffeeButton.titleLabel?.font =  UIFont(name: "Helvetica", size: 50)
        cookCoffeeButton.addTarget(self, action: #selector(cookCoffee), for: .allEvents)
        cookCoffeeButton.pulsate()
        cookCoffeeButton.isHidden = true
        cookCoffeeButton.layer.zPosition = 1
        self.view.addSubview(cookCoffeeButton)
        setUpCoffeeButtonConstraints()
    }
//    this is the function added to the coffeeButton
    @objc public func cookCoffee(){
        cookCoffeeButton.isHidden = true
        centeredImage.isHidden = false
        player.play()
        let timer = Timer.scheduledTimer(timeInterval: 1.5, target: self, selector: #selector(coffee), userInfo: nil, repeats: false)
    }
    
    @objc func coffee() {
        centeredImage.image = UIImage(named: "tazzina.png")
    }
    
}

//extension with function that allows to the button to pulsate
extension UIButton{
    func pulsate() {
        let pulse = CASpringAnimation(keyPath: "transform.scale")
        pulse.duration =  3
        pulse.fromValue = 0.90
        pulse.toValue = 1.0
        pulse.autoreverses = true
        pulse.repeatCount = .infinity
        pulse.initialVelocity = 0.5
        pulse.damping = 1.0
        layer.add(pulse, forKey: "pulse")
    }
}

