/*:
 ![title](foodler.png)
 
 ### 💭Inspiration:
 _In this playground I wanted to mix both my passion, cooking and technlogy; in fact here you are going to learn in a very very simple way how to cook the most famous italian dishes: Coffee, Pizza and Pasta._
 
 ## 🍟Description:
 The Playground is divided into three steps, from the simplest one to the complex one, you can choose to start with simple level (Coffee) and go through other levels swiping the different pages, or you can select the level you want through pages to start with medium or difficult ones.
 
 For all the levels what you have to do is to drag and drop the ingredients in the center of the screen, when the ingredients are finished (in Pizza level) an owen apper you have to click on the it to cook the dish, for the Pasta and Coffee level the Cook button will appear when you drag and drop the spaghetti.
 I decided to name this playground Foodler because I've merged to word food and lover.
 

 ## 💻Technologies:
 For this playground I've used UIKit, so the technologies related to this, for example Gesture Recognizer, Button, Images that are all drawn by me.
 I suggest you to try on iPad Pro 12,9"
 
 ## Go to the Next page for the First level
 [Start](@next)
 */

//: _Playground made by Fabio Salvo_


